#ifndef __UART_IT_H__
#define __UART_IT_H__

#include "usart.h"

void USART2_IRQHandler(void);

#endif /* __UART_IT_H__ */
