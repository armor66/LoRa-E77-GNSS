#ifndef __EXTI_IT_H
#define __EXTI_IT_H

void EXTI0_IRQHandler(void);	//(BTN_3_Pin)
void EXTI1_IRQHandler(void);	//(BTN_2_Pin)
void EXTI4_IRQHandler(void);	//(BTN_1_Pin)
void EXTI9_5_IRQHandler(void);	//(PPS_Pin)
#endif /* __EXTI_IT_H */
